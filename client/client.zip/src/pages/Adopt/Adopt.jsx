import React from "react";

const Adopt = () => {
  return <div>Adopt</div>;
};

export default Adopt;
