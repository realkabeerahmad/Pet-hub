import { Box, MenuItem, Select, TextField } from "@mui/material";
import React from "react";
import { Link } from "react-router-dom";

const Shop = () => {
  return (
    <div>
      <div className="shop-header">
        <TextField placeholder="Search"></TextField>
        <Link to="/shop/cart">Cart</Link>
      </div>
      <div className="shop-container">
        <div className="shop-left">
          <Box>
            <TextField label="Demo"></TextField>
            <Select label="Demo">
              <MenuItem>Demo</MenuItem>
            </Select>
            <Select label="Demo"></Select>
            <Box>
              <TextField label="Demo-From"></TextField>
              <TextField label="Demo-To"></TextField>
            </Box>
          </Box>
        </div>
      </div>
    </div>
  );
};

export default Shop;
