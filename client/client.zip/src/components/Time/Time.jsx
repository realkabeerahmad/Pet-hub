import React from "react";

const Time = () => {
  return (
    <table>
      <tbody>
        <tr>
          <th>Time Name</th>
          <td>
            <button>Edit</button>
            <button>Delete</button>
          </td>
        </tr>
        <tr>
          <td>10:30 AM</td>
        </tr>
      </tbody>
    </table>
  );
};

export default Time;
